﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ms_categorias.Modelo;

namespace ms_categorias.Negocio
{
    public interface INegocioCategorias
    {
        List<Categoria> GetCategorias();
        Categoria GetCategoria(int codCategoria);
        void CrearCategoria(Categoria categoria);
        void BorrarCategoria(int codCategoria);
        void ModificarCategoria(int codCategoria, Categoria categoria);
    }
}
