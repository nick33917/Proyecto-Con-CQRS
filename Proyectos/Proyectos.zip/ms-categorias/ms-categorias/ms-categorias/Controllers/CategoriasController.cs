﻿using System.Collections.Generic;
using Microsoft.AspNetCore.Mvc;
using ms_categorias.Negocio;
using ms_categorias.Modelo;


namespace ms_categorias.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CategoriasController : ControllerBase
    {
        private readonly INegocioCategorias _negocioCategorias;
        public CategoriasController(INegocioCategorias negocioCategorias)
        {
            _negocioCategorias = negocioCategorias;
        }

        // GET api/values
        [HttpGet]
        public ActionResult<IEnumerable<Categoria>> Get()
        {
            return _negocioCategorias.GetCategorias();
        }

        // GET api/values/5
        [HttpGet("{id}")]
        public ActionResult<Categoria> Get(int id)
        {
            return _negocioCategorias.GetCategoria(id);
        }

        // POST api/values
        [HttpPost]
        public void Post([FromBody] Categoria value)
        {
            _negocioCategorias.CrearCategoria(value);
        }

        // PUT api/values/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody] Categoria value)
        {
            _negocioCategorias.ModificarCategoria(id, value);
        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
            _negocioCategorias.BorrarCategoria(id);
        }
    }
}
