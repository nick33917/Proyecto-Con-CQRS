﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using ms_equipos.Modelo;
using Base_de_Datos.DB;
using Newtonsoft.Json;
using Microsoft.EntityFrameworkCore;

namespace ms_equipos.Negocio
{
    public class NegocioEquipo : INegocioEquipo
    {
        private readonly RRHHContext _db;
        private readonly IMapper _mapper;

         public NegocioEquipo(RRHHContext db, IMapper mapper)
         {
            _db = db;
            _mapper = mapper;

         }

        public void BorrarEquipo(int codEquipo)
        {
            var result = _db.TblGrupos.FirstOrDefault(c => c.CodGrupo == codEquipo);
            _db.TblGrupos.Remove(result);
            _db.SaveChanges();
        }

        public bool CrearEquipo(Equipo equipo)
        {
            string jsonInput = JsonConvert.SerializeObject(equipo);

            //Console.WriteLine($"{jsonInput}");
            //Console.ReadLine();
            try
            {
                TblGrupos grupos = new TblGrupos
                 {
                    CodGrupo = equipo.CodGrupo,
                    NombreGrupo = equipo.NombreGrupo,
                    Planifica = equipo.Planifica
                   
                };
                Console.WriteLine(grupos.ToString());

                _db.TblGrupos.Add(grupos);
                Console.Write(grupos);
                _db.SaveChanges();
                return true;
            }
            catch (Exception ex)
            {

                Console.WriteLine($"Error en metodo CrearEquipo(Equipo {jsonInput}): {ex.ToString()}");
                return false;
            }

        }

        public List<Equipo> GetEquipos()
        {
            return _mapper.Map<List<Equipo>>(_db.TblGrupos.ToList());

        }

        public Equipo GetEquipo(int codGrupo)
        {
            return _mapper.Map<Equipo>(_db.TblGrupos.FirstOrDefault(c => c.CodGrupo == codGrupo));
        }

        public void ModificarEquipo(int codEquipo, Equipo equipo)
        {
            var result = _db.TblGrupos.FirstOrDefault(c => c.CodGrupo == codEquipo);

            if(equipo.NombreGrupo !=null)
            {
                result.NombreGrupo = equipo.NombreGrupo;
            }
            if(equipo.Planifica !=null)
            {
                result.Planifica = equipo.Planifica;
            }
            _db.Entry(result).State = EntityState.Modified;
            _db.SaveChanges();
        }
    }

}