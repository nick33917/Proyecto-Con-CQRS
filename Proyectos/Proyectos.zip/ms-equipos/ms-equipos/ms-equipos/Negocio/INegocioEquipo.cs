﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ms_equipos.Modelo;

namespace ms_equipos.Negocio
{
    public interface INegocioEquipo
    {
        List<Equipo> GetEquipos();
        Equipo GetEquipo(int codGrupo);
        Boolean CrearEquipo(Equipo equipo);
        void BorrarEquipo(int codEquipo);
        void ModificarEquipo(int codEquipo, Equipo equipo);


    }
}
