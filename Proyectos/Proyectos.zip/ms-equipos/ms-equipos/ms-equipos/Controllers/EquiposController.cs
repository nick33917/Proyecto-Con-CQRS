﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Base_de_Datos.DB;
using ms_equipos.Negocio;
using ms_equipos.Modelo;

namespace ms_equipos.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EquiposController : ControllerBase
    {
        private readonly INegocioEquipo _negocioEquipo;

        public EquiposController(INegocioEquipo negocioEquipo)
        {
            _negocioEquipo = negocioEquipo;
        }



        // GET api/values
        [HttpGet]
        public ActionResult<IEnumerable<Equipo>> Get()
        {
            return _negocioEquipo.GetEquipos();
          
        }

        // GET api/values/5
        [HttpGet("{id}")]
        public ActionResult<Equipo> Get(int id)
        {
            return _negocioEquipo.GetEquipo(id);
        }

        // POST api/values
        [HttpPost]
        public string Post([FromBody] Equipo value)
        {

            if (_negocioEquipo.CrearEquipo(value))
            {
                return "se ingreso bien ";
            }
            else{
                return "fallo ";

            }
        }

        // PUT api/values/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody] Equipo value)
        {
            _negocioEquipo.ModificarEquipo(id, value);
        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
            _negocioEquipo.BorrarEquipo(id);

        }
    }
}
