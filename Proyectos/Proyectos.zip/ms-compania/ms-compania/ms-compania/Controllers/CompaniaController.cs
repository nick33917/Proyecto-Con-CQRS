﻿using System.Collections.Generic;
using Microsoft.AspNetCore.Mvc;
//using Base_de_Datos.DB;
using ms_compania.Negocio;
using ms_compania.Modelo;

namespace ms_compania.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CompaniaController : ControllerBase
    {
        public readonly INegocioCompania _compania;
        
        public CompaniaController(INegocioCompania compania)
        {
            _compania = compania;
        }

        // GET api/values
        [HttpGet]
        public ActionResult<IEnumerable<Compania>> Get()
        {
            return _compania.GetCompanias();
        }

        // GET api/values/5
        [HttpGet("{id}")]
        public ActionResult<Compania> Get(int id)
        {
            return _compania.GetCompania(id);
        }

        // POST api/values
        [HttpPost]
        public void Post([FromBody] Compania value)
        {
            _compania.CrearCompania(value);
        }

        // PUT api/values/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody] Compania value)
        {
            _compania.ModificarCompania(id,value);
        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
            _compania.BorrarCompania(id);
        }
    }
}
