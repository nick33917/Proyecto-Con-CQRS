﻿using System;
using System.Collections.Generic;

namespace Base_de_Datos.DB
{
    public partial class TblRecursos
    {
        public int Anio { get; set; }
        public int CodPeriodo { get; set; }
        public int CodGrupo { get; set; }
        public double? Baseline { get; set; }
        public double? Adicional { get; set; }
        public double? SobreStaff { get; set; }
        public double? CompromisoTotal { get; set; }
        public double? Evolutivo { get; set; }
        public double? PorcNoProd { get; set; }
        public double? PorcCorrectivo { get; set; }
        public double? Expres { get; set; }
        public double? Funcionales { get; set; }
        public double? Soporte { get; set; }
        public double? Sap { get; set; }
        public double? PorcExpres { get; set; }
        public double? PorcFuncionales { get; set; }
        public double? PorcSoporte { get; set; }
        public double? PorcSap { get; set; }
    }
}
