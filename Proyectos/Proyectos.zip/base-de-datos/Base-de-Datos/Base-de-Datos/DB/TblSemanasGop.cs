﻿using System;
using System.Collections.Generic;

namespace Base_de_Datos.DB
{
    public partial class TblSemanasGop
    {
        public int CodSemana { get; set; }
        public int? Codperiodo { get; set; }
        public int? Año { get; set; }
        public DateTime? Lunes { get; set; }
    }
}
