﻿using System;
using System.Collections.Generic;

namespace Base_de_Datos.DB
{
    public partial class TblParticipantes
    {
        public int CodUsuario { get; set; }
        public int NumGalar { get; set; }
        public int CodTipoGalar { get; set; }
        public int CodAcuerdo { get; set; }
        public int CodGrupo { get; set; }
    }
}
