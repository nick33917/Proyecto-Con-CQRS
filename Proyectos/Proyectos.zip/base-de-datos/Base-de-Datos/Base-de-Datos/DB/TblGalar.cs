﻿using System;
using System.Collections.Generic;

namespace Base_de_Datos.DB
{
    public partial class TblGalar
    {
        public int NumGalar { get; set; }
        public int CodTipoGalar { get; set; }
        public int? CodSubTipoGalar { get; set; }
        public int? CodUsuarioResponsable { get; set; }
        public string CodAcuerdoReferencia { get; set; }
        public string NombreGalar { get; set; }
        public string Comentarios { get; set; }
        public int? CodGrupo { get; set; }
        public string Estado { get; set; }

        public virtual TblTipoGalar CodTipoGalarNavigation { get; set; }
    }
}
