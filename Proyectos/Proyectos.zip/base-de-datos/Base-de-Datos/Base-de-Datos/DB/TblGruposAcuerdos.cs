﻿using System;
using System.Collections.Generic;

namespace Base_de_Datos.DB
{
    public partial class TblGruposAcuerdos
    {
        public int CodAcuerdo { get; set; }
        public int? CodGrupo { get; set; }
        public int? Original { get; set; }

        public virtual TblAcuerdos CodAcuerdoNavigation { get; set; }
        public virtual TblGrupos CodGrupoNavigation { get; set; }
    }
}
