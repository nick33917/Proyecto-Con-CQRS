﻿using System;
using System.Collections.Generic;

namespace Base_de_Datos.DB
{
    public partial class TblPeriodoDetalle
    {
        public int CodPeriodo { get; set; }
        public int Mes { get; set; }

        public virtual TblPeriodos CodPeriodoNavigation { get; set; }
    }
}
