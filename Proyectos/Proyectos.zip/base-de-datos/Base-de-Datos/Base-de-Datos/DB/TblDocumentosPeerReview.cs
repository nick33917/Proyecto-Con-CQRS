﻿using System;
using System.Collections.Generic;

namespace Base_de_Datos.DB
{
    public partial class TblDocumentosPeerReview
    {
        public TblDocumentosPeerReview()
        {
            TblPeerReview = new HashSet<TblPeerReview>();
        }

        public string CodTipoDocumento { get; set; }
        public string DescripcionDocPeer { get; set; }

        public virtual ICollection<TblPeerReview> TblPeerReview { get; set; }
    }
}
