﻿using System;
using System.Collections.Generic;

namespace Base_de_Datos.DB
{
    public partial class TblEstados
    {
        public int CodEstado { get; set; }
        public string DescripcionEstado { get; set; }
        public string CodTipoGalar { get; set; }
    }
}
