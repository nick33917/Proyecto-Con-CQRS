﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace Base_de_Datos.DB
{
    public partial class RRHHContext : DbContext
    {
        public RRHHContext()
        {
        }

        public RRHHContext(DbContextOptions<RRHHContext> options)
            : base(options)
        {
        }

        public virtual DbSet<TblAcuerdos> TblAcuerdos { get; set; }
        public virtual DbSet<TblCategorias> TblCategorias { get; set; }
        public virtual DbSet<TblCompany> TblCompany { get; set; }
        public virtual DbSet<TblDetalleHorasGestionGop> TblDetalleHorasGestionGop { get; set; }
        public virtual DbSet<TblDetalleHorasGop> TblDetalleHorasGop { get; set; }
        public virtual DbSet<TblDocumentosPeerReview> TblDocumentosPeerReview { get; set; }
        public virtual DbSet<TblEstados> TblEstados { get; set; }
        public virtual DbSet<TblEstadosPeerReview> TblEstadosPeerReview { get; set; }
        public virtual DbSet<TblEvaluacion> TblEvaluacion { get; set; }
        public virtual DbSet<TblGalar> TblGalar { get; set; }
        public virtual DbSet<TblGrupos> TblGrupos { get; set; }
        public virtual DbSet<TblGruposAcuerdos> TblGruposAcuerdos { get; set; }
        public virtual DbSet<TblGruposGop> TblGruposGop { get; set; }
        public virtual DbSet<TblHorasExtraOpp> TblHorasExtraOpp { get; set; }
        public virtual DbSet<TblItemEvaluacion> TblItemEvaluacion { get; set; }
        public virtual DbSet<TblObs> TblObs { get; set; }
        public virtual DbSet<TblParametros> TblParametros { get; set; }
        public virtual DbSet<TblParticipantes> TblParticipantes { get; set; }
        public virtual DbSet<TblParticipantesComentarios> TblParticipantesComentarios { get; set; }
        public virtual DbSet<TblPeerReview> TblPeerReview { get; set; }
        public virtual DbSet<TblPerfil> TblPerfil { get; set; }
        public virtual DbSet<TblPeriodoDetalle> TblPeriodoDetalle { get; set; }
        public virtual DbSet<TblPeriodos> TblPeriodos { get; set; }
        public virtual DbSet<TblPlanificacion> TblPlanificacion { get; set; }
        public virtual DbSet<TblPuesto> TblPuesto { get; set; }
        public virtual DbSet<TblRebuildCalculoStats> TblRebuildCalculoStats { get; set; }
        public virtual DbSet<TblRebuildConfig> TblRebuildConfig { get; set; }
        public virtual DbSet<TblRebuildCronograma> TblRebuildCronograma { get; set; }
        public virtual DbSet<TblRebuildException> TblRebuildException { get; set; }
        public virtual DbSet<TblRebuildExecutionGrupo> TblRebuildExecutionGrupo { get; set; }
        public virtual DbSet<TblRebuildExecutionLog> TblRebuildExecutionLog { get; set; }
        public virtual DbSet<TblRebuildExecutionLogEvento> TblRebuildExecutionLogEvento { get; set; }
        public virtual DbSet<TblRebuildGrupos> TblRebuildGrupos { get; set; }
        public virtual DbSet<TblRebuildHistoryEstadistica> TblRebuildHistoryEstadistica { get; set; }
        public virtual DbSet<TblRecursos> TblRecursos { get; set; }
        public virtual DbSet<TblRiesgoOcurrencia> TblRiesgoOcurrencia { get; set; }
        public virtual DbSet<TblRiesgoSeveridad> TblRiesgoSeveridad { get; set; }
        public virtual DbSet<TblRiesgos> TblRiesgos { get; set; }
        public virtual DbSet<TblSemanasGop> TblSemanasGop { get; set; }
        public virtual DbSet<TblTipoGalar> TblTipoGalar { get; set; }
        public virtual DbSet<TblUsuarios> TblUsuarios { get; set; }
        public virtual DbSet<TblUsuariosMail> TblUsuariosMail { get; set; }
        public virtual DbSet<TblUsuariosTelefono> TblUsuariosTelefono { get; set; }
        public virtual DbSet<TblVersiones> TblVersiones { get; set; }

        // Unable to generate entity type for table 'dbo.tblFaltanteGalarTime'. Please see the warning messages.
        // Unable to generate entity type for table 'dbo.tblFacturacion'. Please see the warning messages.
        // Unable to generate entity type for table 'dbo.tempTabSpaceUsed'. Please see the warning messages.
        // Unable to generate entity type for table 'dbo.tempTabStatsList'. Please see the warning messages.
        // Unable to generate entity type for table 'dbo.tblAreaOportunidad'. Please see the warning messages.
        // Unable to generate entity type for table 'dbo.tblGrupoOportunidad'. Please see the warning messages.
        // Unable to generate entity type for table 'dbo.tblEstadoOportunidad'. Please see the warning messages.
        // Unable to generate entity type for table 'dbo.tblOportunidad_TMP'. Please see the warning messages.
        // Unable to generate entity type for table 'dbo.tblGruposCapacidad'. Please see the warning messages.
        // Unable to generate entity type for table 'dbo.tblDetalleHorasBatch'. Please see the warning messages.
        // Unable to generate entity type for table 'dbo.tblAcuerdosHorasBatch_tmp'. Please see the warning messages.
        // Unable to generate entity type for table 'dbo.tblSubTipoGalar'. Please see the warning messages.
        // Unable to generate entity type for table 'dbo.tblAcuerdosHorasBatch'. Please see the warning messages.
        // Unable to generate entity type for table 'dbo.tblIncidentesHorasBatch'. Please see the warning messages.
        // Unable to generate entity type for table 'dbo.tblIncidentesHorasBatch_tmp'. Please see the warning messages.
        // Unable to generate entity type for table 'dbo.tblOportunidadHist'. Please see the warning messages.
        // Unable to generate entity type for table 'dbo.tblDetalleHoras'. Please see the warning messages.
        // Unable to generate entity type for table 'dbo.tbltemporalGOP'. Please see the warning messages.
        // Unable to generate entity type for table 'dbo.tblInformePeriodoGOP'. Please see the warning messages.
        // Unable to generate entity type for table 'dbo.tblUsuariosGrupo'. Please see the warning messages.
        // Unable to generate entity type for table 'dbo.tblGestionOperativa'. Please see the warning messages.
        // Unable to generate entity type for table 'dbo.tblDetalleHorasTemp'. Please see the warning messages.
        // Unable to generate entity type for table 'dbo.tblPoolesGOPTemp'. Please see the warning messages.
        // Unable to generate entity type for table 'dbo.tblSkill'. Please see the warning messages.
        // Unable to generate entity type for table 'dbo.tblBackLog'. Please see the warning messages.
        // Unable to generate entity type for table 'dbo.tblOwnerOportunidad'. Please see the warning messages.
        // Unable to generate entity type for table 'dbo.tblOportunidad'. Please see the warning messages.
        // Unable to generate entity type for table 'dbo.tblHorasProductivas'. Please see the warning messages.
        // Unable to generate entity type for table 'dbo.tblG_Reportes'. Please see the warning messages.
        // Unable to generate entity type for table 'dbo.tblHorasExtraMyTE'. Please see the warning messages.
        // Unable to generate entity type for table 'dbo.tblTimeDetailsTemp'. Please see the warning messages.
        // Unable to generate entity type for table 'dbo.tblMotivos'. Please see the warning messages.
        // Unable to generate entity type for table 'dbo.tblAcuerdosHoras'. Please see the warning messages.
        // Unable to generate entity type for table 'dbo.tblWBS'. Please see the warning messages.
        // Unable to generate entity type for table 'dbo.tblWBSAcuerdo'. Please see the warning messages.

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
                optionsBuilder.UseSqlServer("Data Source=SFPGESTIONApp,4000;Initial Catalog=SFPGESTION;Persist Security Info=True;User ID=utabl01m;Password=W5UsBx5dVAi$");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.HasAnnotation("ProductVersion", "2.2.4-servicing-10062")
                .HasAnnotation("Relational:DefaultSchema", "utabl01m");

            modelBuilder.Entity<TblAcuerdos>(entity =>
            {
                entity.HasKey(e => e.CodAcuerdo);

                entity.ToTable("tblAcuerdos", "dbo");

                entity.Property(e => e.CodAcuerdo).HasColumnName("codAcuerdo");

                entity.Property(e => e.CodUsuarioresponsable).HasColumnName("codUsuarioresponsable");

                entity.Property(e => e.Evolutivo).HasColumnName("evolutivo");

                entity.Property(e => e.NombreAcuerdo)
                    .IsRequired()
                    .HasColumnName("nombreAcuerdo")
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.NombreAcuerdoCorto)
                    .HasColumnName("nombreAcuerdoCorto")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Tipo)
                    .HasColumnName("tipo")
                    .HasMaxLength(4)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<TblCategorias>(entity =>
            {
                entity.HasKey(e => e.CodCategoria);

                entity.ToTable("tblCategorias", "dbo");

                entity.Property(e => e.CodCategoria)
                    .HasColumnName("codCategoria")
                    .ValueGeneratedNever();

                entity.Property(e => e.Level)
                    .HasColumnName("level")
                    .HasMaxLength(2)
                    .IsUnicode(false);

                entity.Property(e => e.NombreCategoria)
                    .IsRequired()
                    .HasColumnName("nombreCategoria")
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.Skill)
                    .HasColumnName("skill")
                    .HasMaxLength(14)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<TblCompany>(entity =>
            {
                entity.HasKey(e => e.CodCompany);

                entity.ToTable("tblCompany", "dbo");

                entity.Property(e => e.CodCompany)
                    .HasColumnName("codCompany")
                    .ValueGeneratedNever();

                entity.Property(e => e.Company)
                    .HasColumnName("company")
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<TblDetalleHorasGestionGop>(entity =>
            {
                entity.HasKey(e => e.CodDetalle);

                entity.ToTable("tblDetalleHorasGestionGOP", "dbo");

                entity.Property(e => e.CodDetalle).HasColumnName("codDetalle");

                entity.Property(e => e.Año).HasColumnName("año");

                entity.Property(e => e.CodGestionOperativa).HasColumnName("codGestionOperativa");

                entity.Property(e => e.CodSemana).HasColumnName("codSemana");

                entity.Property(e => e.CodUsuario).HasColumnName("codUsuario");

                entity.Property(e => e.Codperiodo).HasColumnName("codperiodo");

                entity.Property(e => e.Incurrido)
                    .HasColumnName("incurrido")
                    .HasColumnType("numeric(6, 2)");
            });

            modelBuilder.Entity<TblDetalleHorasGop>(entity =>
            {
                entity.HasKey(e => e.CodDetalle);

                entity.ToTable("tblDetalleHorasGOP", "dbo");

                entity.Property(e => e.CodDetalle).HasColumnName("codDetalle");

                entity.Property(e => e.Año).HasColumnName("año");

                entity.Property(e => e.CodOportunidad).HasColumnName("cod_oportunidad");

                entity.Property(e => e.CodSemana).HasColumnName("codSemana");

                entity.Property(e => e.CodUsuario).HasColumnName("codUsuario");

                entity.Property(e => e.Codacuerdo).HasColumnName("codacuerdo");

                entity.Property(e => e.Codgrupo).HasColumnName("codgrupo");

                entity.Property(e => e.Codperiodo).HasColumnName("codperiodo");

                entity.Property(e => e.Incurrido)
                    .HasColumnName("incurrido")
                    .HasColumnType("numeric(6, 2)");
            });

            modelBuilder.Entity<TblDocumentosPeerReview>(entity =>
            {
                entity.HasKey(e => e.CodTipoDocumento);

                entity.ToTable("tblDocumentosPeerReview", "dbo");

                entity.Property(e => e.CodTipoDocumento)
                    .HasColumnName("codTipoDocumento")
                    .HasMaxLength(5)
                    .IsUnicode(false)
                    .ValueGeneratedNever();

                entity.Property(e => e.DescripcionDocPeer)
                    .HasMaxLength(30)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<TblEstados>(entity =>
            {
                entity.HasKey(e => e.CodEstado);

                entity.ToTable("tblEstados", "dbo");

                entity.Property(e => e.CodEstado)
                    .HasColumnName("codEstado")
                    .ValueGeneratedNever();

                entity.Property(e => e.CodTipoGalar)
                    .IsRequired()
                    .HasColumnName("codTipoGalar")
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.DescripcionEstado)
                    .IsRequired()
                    .HasColumnName("descripcionEstado")
                    .HasMaxLength(60)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<TblEstadosPeerReview>(entity =>
            {
                entity.HasKey(e => e.CodEstadoPeer);

                entity.ToTable("tblEstadosPeerReview", "dbo");

                entity.Property(e => e.CodEstadoPeer)
                    .HasColumnName("codEstadoPeer")
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .ValueGeneratedNever();

                entity.Property(e => e.DescripcionPeer)
                    .IsRequired()
                    .HasColumnName("descripcionPeer")
                    .HasMaxLength(10)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<TblEvaluacion>(entity =>
            {
                entity.HasKey(e => new { e.IdItemEvaluacion, e.CodUsuario, e.CodUsuarioAlta, e.AnioFiscal });

                entity.ToTable("tblEvaluacion", "dbo");

                entity.Property(e => e.IdItemEvaluacion).HasColumnName("idItemEvaluacion");

                entity.Property(e => e.CodUsuario).HasColumnName("codUsuario");

                entity.Property(e => e.CodUsuarioAlta).HasColumnName("codUsuarioAlta");

                entity.Property(e => e.AnioFiscal).HasColumnName("anioFiscal");

                entity.Property(e => e.Comentario)
                    .IsRequired()
                    .HasColumnName("comentario")
                    .HasColumnType("text");

                entity.Property(e => e.FechaAlta)
                    .HasColumnName("fechaAlta")
                    .HasColumnType("smalldatetime");

                entity.Property(e => e.Ranking)
                    .HasColumnName("ranking")
                    .HasMaxLength(10);

                entity.HasOne(d => d.CodUsuarioNavigation)
                    .WithMany(p => p.TblEvaluacion)
                    .HasForeignKey(d => d.CodUsuario)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_tblEvaluacion_tblUsuarios");

                entity.HasOne(d => d.IdItemEvaluacionNavigation)
                    .WithMany(p => p.TblEvaluacion)
                    .HasForeignKey(d => d.IdItemEvaluacion)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_tblEvaluacion_tblItemEvaluacion");
            });

            modelBuilder.Entity<TblGalar>(entity =>
            {
                entity.HasKey(e => new { e.NumGalar, e.CodTipoGalar })
                    .HasName("PK_tblGalar_1");

                entity.ToTable("tblGalar", "dbo");

                entity.Property(e => e.NumGalar).HasColumnName("numGalar");

                entity.Property(e => e.CodTipoGalar).HasColumnName("codTipoGalar");

                entity.Property(e => e.CodAcuerdoReferencia)
                    .HasColumnName("codAcuerdoReferencia")
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.CodGrupo).HasColumnName("codGrupo");

                entity.Property(e => e.CodSubTipoGalar).HasColumnName("codSubTipoGalar");

                entity.Property(e => e.CodUsuarioResponsable).HasColumnName("codUsuarioResponsable");

                entity.Property(e => e.Comentarios)
                    .HasColumnName("comentarios")
                    .HasColumnType("text");

                entity.Property(e => e.Estado).HasMaxLength(15);

                entity.Property(e => e.NombreGalar)
                    .IsRequired()
                    .HasColumnName("nombreGalar")
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.HasOne(d => d.CodTipoGalarNavigation)
                    .WithMany(p => p.TblGalar)
                    .HasForeignKey(d => d.CodTipoGalar)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_tblGalar_tblTipoGalar");
            });

            modelBuilder.Entity<TblGrupos>(entity =>
            {
                entity.HasKey(e => e.CodGrupo);

                entity.ToTable("tblGrupos", "dbo");

                entity.Property(e => e.CodGrupo).HasColumnName("codGrupo");

                entity.Property(e => e.NombreGrupo)
                    .IsRequired()
                    .HasColumnName("nombreGrupo")
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.Planifica).HasColumnName("planifica");
            });

            modelBuilder.Entity<TblGruposAcuerdos>(entity =>
            {
                entity.HasKey(e => e.CodAcuerdo);

                entity.ToTable("tblGruposAcuerdos", "dbo");

                entity.Property(e => e.CodAcuerdo)
                    .HasColumnName("codAcuerdo")
                    .ValueGeneratedNever();

                entity.Property(e => e.CodGrupo).HasColumnName("codGrupo");

                entity.Property(e => e.Original).HasColumnName("original");

                entity.HasOne(d => d.CodAcuerdoNavigation)
                    .WithOne(p => p.TblGruposAcuerdos)
                    .HasForeignKey<TblGruposAcuerdos>(d => d.CodAcuerdo)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_tblGruposAcuerdos_tblAcuerdos");

                entity.HasOne(d => d.CodGrupoNavigation)
                    .WithMany(p => p.TblGruposAcuerdos)
                    .HasForeignKey(d => d.CodGrupo)
                    .HasConstraintName("FK_tblGruposAcuerdos_tblGrupos");
            });

            modelBuilder.Entity<TblGruposGop>(entity =>
            {
                entity.HasKey(e => e.CodGrupoGop);

                entity.ToTable("tblGruposGOP", "dbo");

                entity.Property(e => e.CodGrupoGop).HasColumnName("codGrupoGOP");

                entity.Property(e => e.CodGrupo).HasColumnName("codGrupo");

                entity.Property(e => e.NombreGrupoGop)
                    .HasColumnName("nombreGrupoGOP")
                    .HasMaxLength(100)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<TblHorasExtraOpp>(entity =>
            {
                entity.HasKey(e => e.IdHora);

                entity.ToTable("tblHorasExtraOPP", "dbo");

                entity.Property(e => e.IdHora).HasColumnName("idHora");

                entity.Property(e => e.Aplicacion)
                    .IsRequired()
                    .HasColumnName("aplicacion")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Aprobada).HasColumnName("aprobada");

                entity.Property(e => e.Cantidadcien).HasColumnName("cantidadcien");

                entity.Property(e => e.Cantidadcincuenta).HasColumnName("cantidadcincuenta");

                entity.Property(e => e.CodUsuario)
                    .HasColumnName("codUsuario")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Comentarios)
                    .HasColumnName("comentarios")
                    .HasMaxLength(200)
                    .IsUnicode(false);

                entity.Property(e => e.Facturable).HasColumnName("facturable");

                entity.Property(e => e.Fecha)
                    .HasColumnName("fecha")
                    .HasColumnType("datetime");

                entity.Property(e => e.Motivo)
                    .IsRequired()
                    .HasColumnName("motivo")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Periodo).HasColumnName("periodo");

                entity.Property(e => e.Responsable).HasColumnName("responsable");
            });

            modelBuilder.Entity<TblItemEvaluacion>(entity =>
            {
                entity.HasKey(e => e.IdItemEvaluacion);

                entity.ToTable("tblItemEvaluacion", "dbo");

                entity.Property(e => e.IdItemEvaluacion).HasColumnName("idItemEvaluacion");

                entity.Property(e => e.Descripcion)
                    .HasColumnName("descripcion")
                    .HasMaxLength(100)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<TblObs>(entity =>
            {
                entity.HasKey(e => e.CodObs);

                entity.ToTable("tblOBS", "dbo");

                entity.Property(e => e.CodObs).HasColumnName("codOBS");

                entity.Property(e => e.Obs)
                    .HasColumnName("OBS")
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<TblParametros>(entity =>
            {
                entity.HasKey(e => e.CodParametro);

                entity.ToTable("tblParametros", "dbo");

                entity.Property(e => e.CodParametro).HasColumnName("codParametro");

                entity.Property(e => e.DesParametro)
                    .HasColumnName("desParametro")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.DesValor)
                    .IsRequired()
                    .HasColumnName("desValor")
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<TblParticipantes>(entity =>
            {
                entity.HasKey(e => new { e.CodUsuario, e.NumGalar, e.CodTipoGalar, e.CodAcuerdo, e.CodGrupo })
                    .HasName("PK_tblParticipantes_1");

                entity.ToTable("tblParticipantes", "dbo");

                entity.Property(e => e.CodUsuario).HasColumnName("codUsuario");

                entity.Property(e => e.NumGalar).HasColumnName("numGalar");

                entity.Property(e => e.CodTipoGalar).HasColumnName("codTipoGalar");

                entity.Property(e => e.CodAcuerdo).HasColumnName("codAcuerdo");

                entity.Property(e => e.CodGrupo).HasColumnName("codGrupo");
            });

            modelBuilder.Entity<TblParticipantesComentarios>(entity =>
            {
                entity.HasKey(e => new { e.CodParticipante, e.NumGalar, e.CodTipoGalar, e.CodAcuerdo, e.CodUsuarioAlta, e.CodGrupo })
                    .HasName("PK_tblParticipantesComentarios_1");

                entity.ToTable("tblParticipantesComentarios", "dbo");

                entity.Property(e => e.CodParticipante).HasColumnName("codParticipante");

                entity.Property(e => e.NumGalar).HasColumnName("numGalar");

                entity.Property(e => e.CodTipoGalar).HasColumnName("codTipoGalar");

                entity.Property(e => e.CodAcuerdo).HasColumnName("codAcuerdo");

                entity.Property(e => e.CodUsuarioAlta).HasColumnName("codUsuarioAlta");

                entity.Property(e => e.CodGrupo).HasColumnName("codGrupo");

                entity.Property(e => e.AnioFiscal).HasColumnName("anioFiscal");

                entity.Property(e => e.Comentario)
                    .IsRequired()
                    .HasColumnName("comentario")
                    .HasColumnType("text");

                entity.Property(e => e.Ranking).HasColumnName("ranking");
            });

            modelBuilder.Entity<TblPeerReview>(entity =>
            {
                entity.HasKey(e => new { e.CodTipoDocumento, e.CodAcuerdo, e.NumGalar });

                entity.ToTable("tblPeerReview", "dbo");

                entity.Property(e => e.CodTipoDocumento)
                    .HasColumnName("codTipoDocumento")
                    .HasMaxLength(5)
                    .IsUnicode(false);

                entity.Property(e => e.CodAcuerdo)
                    .HasColumnName("codAcuerdo")
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.NumGalar).HasColumnName("numGalar");

                entity.Property(e => e.CodEstadoPeer)
                    .IsRequired()
                    .HasColumnName("codEstadoPeer")
                    .HasMaxLength(1)
                    .IsUnicode(false);

                entity.Property(e => e.CodUsuario).HasColumnName("codUsuario");

                entity.Property(e => e.CodUsuarioController).HasColumnName("codUsuarioController");

                entity.Property(e => e.CodUsuarioRevisor).HasColumnName("codUsuarioRevisor");

                entity.Property(e => e.FechaLimite)
                    .HasColumnName("fechaLimite")
                    .HasColumnType("smalldatetime");

                entity.HasOne(d => d.CodEstadoPeerNavigation)
                    .WithMany(p => p.TblPeerReview)
                    .HasForeignKey(d => d.CodEstadoPeer)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_tblPeerReview_tblEstadosPeerReview");

                entity.HasOne(d => d.CodTipoDocumentoNavigation)
                    .WithMany(p => p.TblPeerReview)
                    .HasForeignKey(d => d.CodTipoDocumento)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_tblPeerReview_tblDocumentosPeerReview");
            });

            modelBuilder.Entity<TblPerfil>(entity =>
            {
                entity.HasKey(e => e.CodPerfil);

                entity.ToTable("tblPerfil", "dbo");

                entity.Property(e => e.CodPerfil).HasColumnName("codPerfil");

                entity.Property(e => e.DesPerfil)
                    .HasColumnName("des_perfil")
                    .HasMaxLength(20)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<TblPeriodoDetalle>(entity =>
            {
                entity.HasKey(e => new { e.CodPeriodo, e.Mes });

                entity.ToTable("tblPeriodoDetalle", "dbo");

                entity.Property(e => e.Mes).HasColumnName("mes");

                entity.HasOne(d => d.CodPeriodoNavigation)
                    .WithMany(p => p.TblPeriodoDetalle)
                    .HasForeignKey(d => d.CodPeriodo)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_tblPeriodoDetalle_tblPeriodos1");
            });

            modelBuilder.Entity<TblPeriodos>(entity =>
            {
                entity.HasKey(e => e.CodPeriodo);

                entity.ToTable("tblPeriodos", "dbo");

                entity.Property(e => e.CodPeriodo)
                    .HasColumnName("codPeriodo")
                    .ValueGeneratedNever();

                entity.Property(e => e.DescripcionPeriodo)
                    .IsRequired()
                    .HasColumnName("descripcionPeriodo")
                    .HasMaxLength(20)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<TblPlanificacion>(entity =>
            {
                entity.HasKey(e => e.CodPlanificacion);

                entity.ToTable("tblPlanificacion", "dbo");

                entity.HasIndex(e => new { e.CodPeriodo, e.Anio, e.CodAcuerdo, e.CodGrupo, e.NumGalar })
                    .HasName("PK_tblPlanificaicon_2");

                entity.Property(e => e.CodPlanificacion).HasColumnName("codPlanificacion");

                entity.Property(e => e.Anio).HasColumnName("anio");

                entity.Property(e => e.Avance)
                    .HasColumnName("avance")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.CheckPeerReview).HasColumnName("checkPeerReview");

                entity.Property(e => e.CodAcuerdo).HasColumnName("codAcuerdo");

                entity.Property(e => e.CodEstado).HasColumnName("codEstado");

                entity.Property(e => e.CodGrupo).HasColumnName("codGrupo");

                entity.Property(e => e.CodGrupoGop).HasColumnName("codGrupoGOP");

                entity.Property(e => e.CodOportunidad).HasColumnName("cod_oportunidad");

                entity.Property(e => e.CodPeriodo).HasColumnName("codPeriodo");

                entity.Property(e => e.CodTipoGalar).HasColumnName("codTipoGalar");

                entity.Property(e => e.Comentarios)
                    .HasColumnName("comentarios")
                    .HasColumnType("text");

                entity.Property(e => e.ComentariosOpp)
                    .HasMaxLength(200)
                    .IsUnicode(false);

                entity.Property(e => e.DesaFechaFin)
                    .HasColumnName("desaFechaFin")
                    .HasColumnType("smalldatetime");

                entity.Property(e => e.DesaFechaHomo)
                    .HasColumnName("desaFechaHomo")
                    .HasColumnType("smalldatetime");

                entity.Property(e => e.DesaFechaInicio)
                    .HasColumnName("desaFechaInicio")
                    .HasColumnType("smalldatetime");

                entity.Property(e => e.DesaFechaInte)
                    .HasColumnName("desaFechaInte")
                    .HasColumnType("smalldatetime");

                entity.Property(e => e.DesaFechaPiloto)
                    .HasColumnName("desaFechaPiloto")
                    .HasColumnType("smalldatetime");

                entity.Property(e => e.DesaFechaProd)
                    .HasColumnName("desaFechaProd")
                    .HasColumnType("smalldatetime");

                entity.Property(e => e.DesaHoras)
                    .HasColumnName("desaHoras")
                    .HasColumnType("numeric(6, 2)")
                    .HasDefaultValueSql("(0)");

                entity.Property(e => e.DescripcionOportunidad)
                    .HasColumnName("descripcionOportunidad")
                    .HasMaxLength(500)
                    .IsUnicode(false);

                entity.Property(e => e.DesvioAcumulado)
                    .HasColumnName("desvioAcumulado")
                    .HasColumnType("numeric(6, 2)");

                entity.Property(e => e.DesvioMensual)
                    .HasColumnName("desvioMensual")
                    .HasColumnType("numeric(6, 2)");

                entity.Property(e => e.EstFechaAdp)
                    .HasColumnName("estFechaADP")
                    .HasColumnType("smalldatetime");

                entity.Property(e => e.EstFechaFin)
                    .HasColumnName("estFechaFin")
                    .HasColumnType("smalldatetime");

                entity.Property(e => e.EstFechaInicio)
                    .HasColumnName("estFechaInicio")
                    .HasColumnType("smalldatetime");

                entity.Property(e => e.EstHoras)
                    .HasColumnName("estHoras")
                    .HasColumnType("numeric(6, 2)")
                    .HasDefaultValueSql("(0)");

                entity.Property(e => e.EstHorasTotales).HasColumnName("estHorasTotales");

                entity.Property(e => e.Evolutivo)
                    .HasColumnName("evolutivo")
                    .HasDefaultValueSql("(0)");

                entity.Property(e => e.FechaRealImplementacion)
                    .HasColumnName("fechaRealImplementacion")
                    .HasColumnType("smalldatetime");

                entity.Property(e => e.FechaUltimaModificacion).HasColumnType("smalldatetime");

                entity.Property(e => e.FechaUltimaModificacionGop)
                    .HasColumnName("FechaUltimaModificacionGOP")
                    .HasColumnType("smalldatetime");

                entity.Property(e => e.Fin)
                    .HasColumnName("fin")
                    .HasColumnType("datetime");

                entity.Property(e => e.Finalizado)
                    .HasColumnName("finalizado")
                    .HasDefaultValueSql("(0)");

                entity.Property(e => e.HorasSolicitadasOpp)
                    .HasColumnType("numeric(7, 2)")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.IncurridoAcumulado)
                    .HasColumnName("incurridoAcumulado")
                    .HasColumnType("numeric(6, 2)");

                entity.Property(e => e.Inicio)
                    .HasColumnName("inicio")
                    .HasColumnType("datetime");

                entity.Property(e => e.LinkPeerReview)
                    .HasColumnName("linkPeerReview")
                    .HasMaxLength(300)
                    .IsUnicode(false);

                entity.Property(e => e.NovedadOpp).HasDefaultValueSql("((0))");

                entity.Property(e => e.NumGalar).HasColumnName("numGalar");

                entity.Property(e => e.NumProblem)
                    .HasColumnName("numProblem")
                    .HasDefaultValueSql("(0)");

                entity.Property(e => e.Prioridad).HasColumnName("prioridad");

                entity.Property(e => e.Responsable1).HasColumnName("responsable1");

                entity.Property(e => e.Responsable2).HasColumnName("responsable2");

                entity.Property(e => e.SeguiEstadoAcuerdo)
                    .HasColumnName("seguiEstadoAcuerdo")
                    .HasMaxLength(15);

                entity.Property(e => e.SeguiFechaFinGalarActual)
                    .HasColumnName("seguiFechaFinGalarActual")
                    .HasColumnType("smalldatetime")
                    .HasDefaultValueSql("(0)");

                entity.Property(e => e.SeguiFechaFinGalarComprometida)
                    .HasColumnName("seguiFechaFinGalarComprometida")
                    .HasColumnType("smalldatetime")
                    .HasDefaultValueSql("(0)");

                entity.Property(e => e.SeguiFechaFinGalarReal)
                    .HasColumnName("seguiFechaFinGalarReal")
                    .HasColumnType("smalldatetime")
                    .HasDefaultValueSql("(0)");

                entity.Property(e => e.SeguiHorasAcuerdoGalarActual)
                    .HasColumnName("seguiHorasAcuerdoGalarActual")
                    .HasColumnType("numeric(7, 2)")
                    .HasDefaultValueSql("(0)");

                entity.Property(e => e.SeguiHorasAcuerdoGalarComprometidas)
                    .HasColumnName("seguiHorasAcuerdoGalarComprometidas")
                    .HasColumnType("numeric(7, 2)")
                    .HasDefaultValueSql("(0)");

                entity.Property(e => e.SeguiHorasAcuerdoGalarInicial)
                    .HasColumnName("seguiHorasAcuerdoGalarInicial")
                    .HasColumnType("numeric(7, 2)")
                    .HasDefaultValueSql("(0)");

                entity.Property(e => e.SeguiHorasIncurridasGalar)
                    .HasColumnName("seguiHorasIncurridasGalar")
                    .HasColumnType("numeric(7, 2)")
                    .HasDefaultValueSql("(0)");

                entity.Property(e => e.SeguiHorasIncurridasGalarEst)
                    .HasColumnName("seguiHorasIncurridasGalarEst")
                    .HasColumnType("numeric(7, 2)")
                    .HasDefaultValueSql("(0)");

                entity.Property(e => e.SeguiHorasIncurridasTotales)
                    .HasColumnName("seguiHorasIncurridasTotales")
                    .HasColumnType("numeric(7, 2)")
                    .HasDefaultValueSql("(0)");

                entity.Property(e => e.Soporte)
                    .HasColumnName("soporte")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.TotalPlanificadas)
                    .HasColumnName("totalPlanificadas")
                    .HasColumnType("numeric(6, 2)");

                entity.Property(e => e.UserControlPeerReview).HasColumnName("userControlPeerReview");
            });

            modelBuilder.Entity<TblPuesto>(entity =>
            {
                entity.HasKey(e => e.CodUsuario);

                entity.ToTable("tblPuesto", "dbo");

                entity.Property(e => e.CodUsuario)
                    .HasColumnName("codUsuario")
                    .ValueGeneratedNever();

                entity.Property(e => e.CodInternoAccTitular).HasColumnName("codInternoAccTitular");

                entity.Property(e => e.CodInternoGaliciaTitular).HasColumnName("codInternoGaliciaTitular");

                entity.Property(e => e.Galcpu)
                    .HasColumnName("GALCPU")
                    .HasMaxLength(9)
                    .IsUnicode(false);

                entity.Property(e => e.Galcpuextra)
                    .HasColumnName("GALCPUExtra")
                    .HasMaxLength(9)
                    .IsUnicode(false);

                entity.Property(e => e.Galmonitor)
                    .HasColumnName("GALMonitor")
                    .HasMaxLength(25)
                    .IsUnicode(false);

                entity.Property(e => e.Galtelefono)
                    .HasColumnName("GALTelefono")
                    .HasMaxLength(9)
                    .IsUnicode(false);

                entity.Property(e => e.InternoAcc)
                    .HasColumnName("internoAcc")
                    .HasMaxLength(5)
                    .IsUnicode(false);

                entity.Property(e => e.InternoGalicia)
                    .HasColumnName("internoGalicia")
                    .HasMaxLength(4)
                    .IsUnicode(false);

                entity.Property(e => e.NroBoca)
                    .HasMaxLength(15)
                    .IsUnicode(false);

                entity.Property(e => e.NroPuesto)
                    .HasMaxLength(5)
                    .IsUnicode(false);

                entity.HasOne(d => d.CodInternoGaliciaTitularNavigation)
                    .WithMany(p => p.TblPuesto)
                    .HasForeignKey(d => d.CodInternoGaliciaTitular)
                    .HasConstraintName("FK_tblPuesto_tblUsuarios");
            });

            modelBuilder.Entity<TblRebuildCalculoStats>(entity =>
            {
                entity.HasKey(e => e.IdUltimoCalculo)
                    .ForSqlServerIsClustered(false);

                entity.ToTable("tbl_Rebuild_CalculoStats", "dbo");

                entity.Property(e => e.IdUltimoCalculo).HasColumnName("idUltimoCalculo");

                entity.Property(e => e.UltEjecucion)
                    .HasColumnName("ultEjecucion")
                    .HasColumnType("datetime");
            });

            modelBuilder.Entity<TblRebuildConfig>(entity =>
            {
                entity.HasKey(e => e.IdReorgConfig)
                    .ForSqlServerIsClustered(false);

                entity.ToTable("tbl_Rebuild_Config", "dbo");

                entity.Property(e => e.IdReorgConfig).HasColumnName("idReorgConfig");

                entity.Property(e => e.Atributo)
                    .IsRequired()
                    .HasMaxLength(60)
                    .IsUnicode(false);

                entity.Property(e => e.Valor).HasColumnType("sql_variant");

                entity.Property(e => e.ValorFin).HasColumnType("sql_variant");
            });

            modelBuilder.Entity<TblRebuildCronograma>(entity =>
            {
                entity.HasKey(e => e.IdReorgCronograma)
                    .ForSqlServerIsClustered(false);

                entity.ToTable("tbl_Rebuild_Cronograma", "dbo");

                entity.Property(e => e.IdReorgCronograma).HasColumnName("idReorgCronograma");

                entity.Property(e => e.Endday)
                    .HasColumnName("endday")
                    .HasMaxLength(6)
                    .IsUnicode(false)
                    .HasDefaultValueSql("('')");

                entity.Property(e => e.Endhour)
                    .HasColumnName("endhour")
                    .HasMaxLength(4)
                    .IsUnicode(false)
                    .HasDefaultValueSql("('')");

                entity.Property(e => e.Groupname)
                    .IsRequired()
                    .HasColumnName("groupname")
                    .HasMaxLength(128);

                entity.Property(e => e.IsEnabled)
                    .HasColumnName("isEnabled")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Paralelismo)
                    .HasColumnName("paralelismo")
                    .HasDefaultValueSql("('')");
            });

            modelBuilder.Entity<TblRebuildException>(entity =>
            {
                entity.HasKey(e => e.IdReorgException)
                    .ForSqlServerIsClustered(false);

                entity.ToTable("tbl_Rebuild_Exception", "dbo");

                entity.Property(e => e.IdReorgException).HasColumnName("idReorgException");

                entity.Property(e => e.AccionRealizar)
                    .HasColumnName("accionRealizar")
                    .HasMaxLength(100)
                    .IsUnicode(false)
                    .HasDefaultValueSql("('')");

                entity.Property(e => e.Schemaname)
                    .IsRequired()
                    .HasColumnName("schemaname")
                    .HasMaxLength(128);

                entity.Property(e => e.Tablename)
                    .IsRequired()
                    .HasColumnName("tablename")
                    .HasMaxLength(128);

                entity.Property(e => e.TipoTarea)
                    .HasColumnName("tipoTarea")
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasDefaultValueSql("('')");
            });

            modelBuilder.Entity<TblRebuildExecutionGrupo>(entity =>
            {
                entity.HasKey(e => e.IdReorgExecutionGrupo);

                entity.ToTable("tbl_Rebuild_ExecutionGrupo", "dbo");

                entity.Property(e => e.IdReorgExecutionGrupo).HasColumnName("idReorgExecutionGrupo");

                entity.Property(e => e.Groupname)
                    .IsRequired()
                    .HasColumnName("groupname")
                    .HasMaxLength(128);

                entity.Property(e => e.Horafin)
                    .HasColumnName("horafin")
                    .HasColumnType("datetime");

                entity.Property(e => e.Horainicio)
                    .HasColumnName("horainicio")
                    .HasColumnType("datetime");

                entity.Property(e => e.IdHistoryStatsFin).HasColumnName("idHistoryStatsFin");

                entity.Property(e => e.IdHistoryStatsInicio).HasColumnName("idHistoryStatsInicio");

                entity.Property(e => e.IdReorgExecutionLogFin).HasColumnName("idReorgExecutionLogFin");

                entity.Property(e => e.IdReorgExecutionLogInicio).HasColumnName("idReorgExecutionLogInicio");

                entity.Property(e => e.Status)
                    .HasColumnName("status")
                    .HasMaxLength(20)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<TblRebuildExecutionLog>(entity =>
            {
                entity.HasKey(e => e.IdReorgExecutionLog);

                entity.ToTable("tbl_Rebuild_ExecutionLog", "dbo");

                entity.Property(e => e.IdReorgExecutionLog).HasColumnName("idReorgExecutionLog");

                entity.Property(e => e.Groupname)
                    .IsRequired()
                    .HasColumnName("groupname")
                    .HasMaxLength(128);

                entity.Property(e => e.Schemaname)
                    .IsRequired()
                    .HasColumnName("schemaname")
                    .HasMaxLength(128);

                entity.Property(e => e.Tablename)
                    .IsRequired()
                    .HasColumnName("tablename")
                    .HasMaxLength(128);

                entity.Property(e => e.Ulthorafin)
                    .HasColumnName("ulthorafin")
                    .HasColumnType("datetime");

                entity.Property(e => e.Ulthorainicio)
                    .HasColumnName("ulthorainicio")
                    .HasColumnType("datetime");
            });

            modelBuilder.Entity<TblRebuildExecutionLogEvento>(entity =>
            {
                entity.HasKey(e => e.IdEventoLog);

                entity.ToTable("tbl_Rebuild_ExecutionLogEvento", "dbo");

                entity.Property(e => e.IdEventoLog).HasColumnName("idEventoLog");

                entity.Property(e => e.Fechahora)
                    .HasColumnName("fechahora")
                    .HasColumnType("datetime");

                entity.Property(e => e.IdReorgExecutionLog).HasColumnName("idReorgExecutionLog");

                entity.Property(e => e.JobId)
                    .HasColumnName("JobID")
                    .HasMaxLength(6)
                    .IsUnicode(false)
                    .HasDefaultValueSql("('')");

                entity.Property(e => e.Mensaje)
                    .HasColumnName("mensaje")
                    .HasMaxLength(500);

                entity.Property(e => e.Origen)
                    .HasColumnName("origen")
                    .HasMaxLength(20);
            });

            modelBuilder.Entity<TblRebuildGrupos>(entity =>
            {
                entity.HasKey(e => new { e.Groupname, e.Schemaname, e.Tablename });

                entity.ToTable("tbl_Rebuild_Grupos", "dbo");

                entity.Property(e => e.Groupname)
                    .HasColumnName("groupname")
                    .HasMaxLength(128);

                entity.Property(e => e.Schemaname)
                    .HasColumnName("schemaname")
                    .HasMaxLength(128);

                entity.Property(e => e.Tablename)
                    .HasColumnName("tablename")
                    .HasMaxLength(128);

                entity.Property(e => e.Descripcion)
                    .HasColumnName("descripcion")
                    .HasMaxLength(200)
                    .IsUnicode(false);

                entity.Property(e => e.FechaUltFullRebuild)
                    .HasColumnName("fechaUltFullRebuild")
                    .HasColumnType("datetime");

                entity.Property(e => e.Ispagelock)
                    .HasColumnName("ispagelock")
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.Ordenexec).HasColumnName("ordenexec");

                entity.Property(e => e.Tiporebuild)
                    .HasColumnName("tiporebuild")
                    .HasMaxLength(20)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<TblRebuildHistoryEstadistica>(entity =>
            {
                entity.HasKey(e => e.IdReorgHistoryStats)
                    .ForSqlServerIsClustered(false);

                entity.ToTable("tbl_Rebuild_HistoryEstadistica", "dbo");

                entity.Property(e => e.IdReorgHistoryStats).HasColumnName("idReorgHistoryStats");

                entity.Property(e => e.AccionTomada)
                    .HasColumnName("accionTomada")
                    .HasMaxLength(10)
                    .IsUnicode(false)
                    .HasDefaultValueSql("('')");

                entity.Property(e => e.Data)
                    .IsRequired()
                    .HasColumnName("data")
                    .HasMaxLength(40)
                    .IsUnicode(false);

                entity.Property(e => e.Fechaejecucion)
                    .HasColumnName("fechaejecucion")
                    .HasColumnType("datetime");

                entity.Property(e => e.Fragmentacion)
                    .HasColumnName("fragmentacion")
                    .HasColumnType("numeric(16, 2)")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.FragmentacionFinal)
                    .HasColumnName("fragmentacionFinal")
                    .HasColumnType("numeric(16, 2)")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Groupname)
                    .IsRequired()
                    .HasColumnName("groupname")
                    .HasMaxLength(128);

                entity.Property(e => e.Idcalculostats).HasColumnName("idcalculostats");

                entity.Property(e => e.IndexSize)
                    .IsRequired()
                    .HasColumnName("index_size")
                    .HasMaxLength(40)
                    .IsUnicode(false);

                entity.Property(e => e.JobId)
                    .HasColumnName("JobID")
                    .HasMaxLength(6)
                    .IsUnicode(false)
                    .HasDefaultValueSql("('')");

                entity.Property(e => e.Numrows).HasColumnName("numrows");

                entity.Property(e => e.Processed)
                    .HasColumnName("processed")
                    .HasDefaultValueSql("((-1))");

                entity.Property(e => e.Reserved)
                    .IsRequired()
                    .HasColumnName("reserved")
                    .HasMaxLength(40)
                    .IsUnicode(false);

                entity.Property(e => e.Schemaname)
                    .IsRequired()
                    .HasColumnName("schemaname")
                    .HasMaxLength(128);

                entity.Property(e => e.Tablename)
                    .IsRequired()
                    .HasColumnName("tablename")
                    .HasMaxLength(128);

                entity.Property(e => e.Unused)
                    .IsRequired()
                    .HasColumnName("unused")
                    .HasMaxLength(40)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<TblRecursos>(entity =>
            {
                entity.HasKey(e => new { e.Anio, e.CodPeriodo, e.CodGrupo })
                    .HasName("PK_dbo.tblRecursos");

                entity.ToTable("tblRecursos", "dbo");
            });

            modelBuilder.Entity<TblRiesgoOcurrencia>(entity =>
            {
                entity.HasKey(e => e.CodOcurrencia);

                entity.ToTable("tblRiesgoOcurrencia", "dbo");

                entity.Property(e => e.CodOcurrencia)
                    .HasColumnName("codOcurrencia")
                    .ValueGeneratedNever();

                entity.Property(e => e.Descripcionocurrencia)
                    .IsRequired()
                    .HasColumnName("descripcionocurrencia")
                    .HasMaxLength(15)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<TblRiesgoSeveridad>(entity =>
            {
                entity.HasKey(e => e.CodSeveridad);

                entity.ToTable("tblRiesgoSeveridad", "dbo");

                entity.Property(e => e.CodSeveridad)
                    .HasColumnName("codSeveridad")
                    .ValueGeneratedNever();

                entity.Property(e => e.DescripcionSeveridad)
                    .IsRequired()
                    .HasColumnName("descripcionSeveridad")
                    .HasMaxLength(10)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<TblRiesgos>(entity =>
            {
                entity.HasKey(e => new { e.NumGalar, e.CodAcuerdo });

                entity.ToTable("tblRiesgos", "dbo");

                entity.Property(e => e.NumGalar).HasColumnName("numGalar");

                entity.Property(e => e.CodAcuerdo)
                    .HasColumnName("codAcuerdo")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.AccionesContingencia)
                    .HasColumnName("accionesContingencia")
                    .HasMaxLength(40)
                    .IsUnicode(false);

                entity.Property(e => e.AccionesMitigacion)
                    .HasColumnName("accionesMitigacion")
                    .HasMaxLength(40)
                    .IsUnicode(false);

                entity.Property(e => e.CodOcurrencia).HasColumnName("codOcurrencia");

                entity.Property(e => e.CodSeveridad).HasColumnName("codSeveridad");

                entity.Property(e => e.DetalleRiesgo)
                    .HasMaxLength(150)
                    .IsUnicode(false);

                entity.HasOne(d => d.CodOcurrenciaNavigation)
                    .WithMany(p => p.TblRiesgos)
                    .HasForeignKey(d => d.CodOcurrencia)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_tblRiesgos_tblRiesgoOcurrencia");

                entity.HasOne(d => d.CodSeveridadNavigation)
                    .WithMany(p => p.TblRiesgos)
                    .HasForeignKey(d => d.CodSeveridad)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_tblRiesgos_tblRiesgoSeveridad");
            });

            modelBuilder.Entity<TblSemanasGop>(entity =>
            {
                entity.HasKey(e => e.CodSemana);

                entity.ToTable("tblSemanasGOP", "dbo");

                entity.Property(e => e.CodSemana).HasColumnName("codSemana");

                entity.Property(e => e.Año).HasColumnName("año");

                entity.Property(e => e.Codperiodo).HasColumnName("codperiodo");

                entity.Property(e => e.Lunes)
                    .HasColumnName("lunes")
                    .HasColumnType("datetime");
            });

            modelBuilder.Entity<TblTipoGalar>(entity =>
            {
                entity.HasKey(e => e.CodTipoGalar);

                entity.ToTable("tblTipoGalar", "dbo");

                entity.Property(e => e.CodTipoGalar)
                    .HasColumnName("codTipoGalar")
                    .ValueGeneratedNever();

                entity.Property(e => e.DescripcionTipoGalar)
                    .HasColumnName("descripcionTipoGalar")
                    .HasMaxLength(30)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<TblUsuarios>(entity =>
            {
                entity.HasKey(e => e.CodUsuario);

                entity.ToTable("tblUsuarios", "dbo");

                entity.Property(e => e.CodUsuario).HasColumnName("codUsuario");

                entity.Property(e => e.ActualEnd)
                    .HasColumnName("Actual_End")
                    .HasColumnType("datetime");

                entity.Property(e => e.ActualStart).HasColumnType("datetime");

                entity.Property(e => e.Apellidousuario)
                    .HasColumnName("apellidousuario")
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.CodAcuerdoOriginal).HasColumnName("codAcuerdoOriginal");

                entity.Property(e => e.CodCategoria).HasColumnName("codCategoria");

                entity.Property(e => e.CodCompany)
                    .HasColumnName("codCompany")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.CodEspecialista).HasColumnName("codEspecialista");

                entity.Property(e => e.CodGerente).HasColumnName("codGerente");

                entity.Property(e => e.CodObs).HasColumnName("codOBS");

                entity.Property(e => e.CodPerfil).HasColumnName("codPerfil");

                entity.Property(e => e.CodSkill).HasColumnName("codSkill");

                entity.Property(e => e.CodSupervisor).HasColumnName("codSupervisor");

                entity.Property(e => e.EnterpriseIdacc)
                    .HasColumnName("EnterpriseIDAcc")
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.Estado).HasColumnName("estado");

                entity.Property(e => e.FechaNacimiento)
                    .HasColumnName("fechaNacimiento")
                    .HasColumnType("datetime");

                entity.Property(e => e.Foto)
                    .HasColumnName("foto")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Galar)
                    .HasColumnName("galar")
                    .HasColumnType("decimal(3, 2)");

                entity.Property(e => e.IngresoAccenture)
                    .HasColumnName("ingresoAccenture")
                    .HasColumnType("datetime");

                entity.Property(e => e.Legajo)
                    .HasColumnName("legajo")
                    .HasMaxLength(8);

                entity.Property(e => e.NombreUsuario)
                    .IsRequired()
                    .HasColumnName("nombreUsuario")
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.NroEmpleadoAcc)
                    .HasMaxLength(9)
                    .IsUnicode(false);

                entity.Property(e => e.NumEmpleado).HasColumnName("numEmpleado");

                entity.Property(e => e.Observaciones)
                    .HasColumnName("observaciones")
                    .HasMaxLength(200)
                    .IsUnicode(false);

                entity.Property(e => e.PlannedEnd)
                    .HasColumnName("Planned_End")
                    .HasColumnType("datetime");

                entity.Property(e => e.PlannedStart)
                    .HasColumnName("Planned_start")
                    .HasColumnType("datetime");

                entity.Property(e => e.RequestDate)
                    .HasColumnName("Request_Date")
                    .HasColumnType("datetime");

                entity.Property(e => e.SerialNumberNotebook)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.HasOne(d => d.CodCategoriaNavigation)
                    .WithMany(p => p.TblUsuarios)
                    .HasForeignKey(d => d.CodCategoria)
                    .HasConstraintName("FK_tblUsuarios_tblCategorias");
            });

            modelBuilder.Entity<TblUsuariosMail>(entity =>
            {
                entity.HasKey(e => e.IdMail);

                entity.ToTable("tblUsuariosMail", "dbo");

                entity.Property(e => e.IdMail).HasColumnName("id_mail");

                entity.Property(e => e.CodUsuario).HasColumnName("codUsuario");

                entity.Property(e => e.Mail)
                    .IsRequired()
                    .HasColumnName("mail")
                    .HasMaxLength(90)
                    .IsUnicode(false);

                entity.Property(e => e.Tipo)
                    .IsRequired()
                    .HasColumnName("tipo")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.HasOne(d => d.CodUsuarioNavigation)
                    .WithMany(p => p.TblUsuariosMail)
                    .HasForeignKey(d => d.CodUsuario)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_tblUsuariosMail_tblUsuarios");
            });

            modelBuilder.Entity<TblUsuariosTelefono>(entity =>
            {
                entity.HasKey(e => e.IdTel);

                entity.ToTable("tblUsuariosTelefono", "dbo");

                entity.Property(e => e.IdTel).HasColumnName("id_tel");

                entity.Property(e => e.CodUsuario).HasColumnName("codUsuario");

                entity.Property(e => e.Numero)
                    .IsRequired()
                    .HasColumnName("numero")
                    .HasMaxLength(15)
                    .IsUnicode(false);

                entity.Property(e => e.Tipo)
                    .IsRequired()
                    .HasColumnName("tipo")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.HasOne(d => d.CodUsuarioNavigation)
                    .WithMany(p => p.TblUsuariosTelefono)
                    .HasForeignKey(d => d.CodUsuario)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_tblUsuariosTelefono_tblUsuarios");
            });

            modelBuilder.Entity<TblVersiones>(entity =>
            {
                entity.HasKey(e => new { e.CodPeriodo, e.Anio, e.CodGrupo, e.NumVersion });

                entity.ToTable("tblVersiones", "dbo");

                entity.Property(e => e.CodPeriodo)
                    .HasColumnName("codPeriodo")
                    .HasMaxLength(2)
                    .IsUnicode(false);

                entity.Property(e => e.Anio)
                    .HasColumnName("anio")
                    .HasMaxLength(4)
                    .IsUnicode(false);

                entity.Property(e => e.CodGrupo).HasColumnName("codGrupo");

                entity.Property(e => e.NumVersion).HasColumnName("numVersion");

                entity.Property(e => e.Descripcion)
                    .HasMaxLength(150)
                    .IsUnicode(false);

                entity.Property(e => e.Fecha)
                    .HasColumnName("fecha")
                    .HasColumnType("smalldatetime");
            });
        }
    }
}
