﻿using System;
using System.Collections.Generic;

namespace Base_de_Datos.DB
{
    public partial class TblRebuildGrupos
    {
        public string Groupname { get; set; }
        public string Schemaname { get; set; }
        public string Tablename { get; set; }
        public long? Ordenexec { get; set; }
        public string Descripcion { get; set; }
        public string Tiporebuild { get; set; }
        public DateTime? FechaUltFullRebuild { get; set; }
        public byte? Ispagelock { get; set; }
    }
}
